go 
int i <- 0
int x
int y 
int k[5] <- {1 2 3 4 5}
get x
get y
end