go
int i <- 0
int x[5] 
i < 5 do:
	get x[i]
	i++:
4 -> i
i >= 0 do:
	put x[i]
	i--:
end