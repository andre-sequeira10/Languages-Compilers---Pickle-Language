go
int y <- 2
int z <- 3
int t
t <- z * 2 + y
put 'resultado - ' t
end 