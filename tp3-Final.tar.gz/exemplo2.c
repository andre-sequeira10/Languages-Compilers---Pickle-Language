go
string a <- 'Grupo n'
int x
get x
put a - x 
end 