go
int h
h <- funcao(5 5)
put h
end 

def funcao(x y):
	if y ~ x : out 1:
	ahoy:out 0: 
:
