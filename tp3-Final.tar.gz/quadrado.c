go
int i <- 1
int x
int y
int result <- 0
get x
i<4 do:
	get y
	if x ~ y: 1->result over:
	i++:
put result 
end 