go 
int result
result <- multiplica(2)
put result
end

def multiplica(x):
int z
get z
z <- z * 2
out z:
