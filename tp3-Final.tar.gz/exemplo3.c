go 
int a 
int h
get a 
h <- funcao(2)
put h
end

def funcao(x):
	int k <- x
	int y 
	get y
	y > 0 do:
		k <- k + y
		y--:
out k:
